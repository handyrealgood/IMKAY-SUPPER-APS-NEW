import * as XLSX from 'xlsx';
import { User, StockOpnameRecord, RawItem } from '../types';

/**
 * Generic utility to export structured tabular data to Excel (.xlsx)
 */
export function exportToExcel(
  filename: string,
  sheetTitle: string,
  headers: string[],
  rows: (string | number | boolean | null | undefined)[][]
) {
  const data = [
    [sheetTitle],
    [],
    headers,
    ...rows
  ];
  const worksheet = XLSX.utils.aoa_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Laporan');

  // Auto column width adjustment
  const maxCols = headers.map((h, i) => {
    let maxLen = h.length;
    rows.forEach(r => {
      const cellVal = r[i] !== undefined && r[i] !== null ? String(r[i]) : '';
      if (cellVal.length > maxLen) maxLen = cellVal.length;
    });
    return { wch: Math.min(Math.max(maxLen + 2, 12), 40) };
  });
  worksheet['!cols'] = maxCols;

  const validName = filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`;
  XLSX.writeFile(workbook, validName);
}

/**
 * Utility to export comprehensive HRD employee directory to Excel (.xlsx)
 */
export function exportEmployeesToExcel(users: User[], brandingName: string = 'Restoran') {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const data = users.map((u, index) => {
    let contractDaysRemaining = '-';
    let contractAlert = 'Aman';

    if (u.contractStatus === 'kontrak' && u.contractEndDate) {
      const end = new Date(u.contractEndDate);
      const diffDays = Math.ceil((end.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      contractDaysRemaining = `${diffDays} hari`;
      if (diffDays < 0) {
        contractAlert = 'KONTRAK HABIS';
      } else if (diffDays <= 60) {
        contractAlert = `PERINGATAN (< 2 Bln / ${diffDays} hari)`;
      } else {
        contractAlert = 'Aktif';
      }
    } else if (u.contractStatus === 'tetap') {
      contractAlert = 'Karyawan Tetap';
    }

    return {
      'No': index + 1,
      'ID Karyawan': u.employeeId || `EMP-${u.id}`,
      'Nama Lengkap': u.name,
      'Username': `@${u.username}`,
      'Jabatan / Peran': u.roleTitle || u.role,
      'Status Kontrak': (u.contractStatus || 'tetap').toUpperCase(),
      'Tgl Mulai Kerja': u.contractStartDate || u.joinDate || '-',
      'Tgl Berakhir Kontrak': u.contractEndDate || '-',
      'Sisa Masa Kontrak': contractDaysRemaining,
      'Status Peringatan HRD': contractAlert,
      'NIK (KTP)': u.nikKtp || (u as any).nik || '-',
      'No. Telepon / WA': u.phone || '-',
      'Email': u.email || '-',
      'Alamat Domisili': u.address || '-',
      'Tanggal Lahir': u.birthDate || '-',
      'Jenis Kelamin': (u as any).gender === 'L' ? 'Laki-laki' : (u as any).gender === 'P' ? 'Perempuan' : '-',
      'Golongan Darah': u.bloodType || '-',
      'Pendidikan Terakhir': u.lastEducation || '-',
      'NPWP': u.npwp || '-',
      'BPJS Ketenagakerjaan': u.bpjsKetenagakerjaan || '-',
      'BPJS Kesehatan': u.bpjsKesehatan || '-',
      'Nama Bank': u.bankName || '-',
      'No. Rekening': u.bankAccountNumber || '-',
      'Atas Nama Rekening': u.bankAccountHolder || '-',
      'Kontak Darurat': u.emergencyContactName || '-',
      'Hubungan Kontak Darurat': u.emergencyContactRelation || '-',
      'No. Telp Darurat': u.emergencyContactPhone || '-',
      'Catatan HRD': (u as any).notes || u.bio || '-'
    };
  });

  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Data Karyawan HRD');

  // Auto column width adjustment
  const maxProps = Object.keys(data[0] || {}).map(key => ({
    wch: Math.max(key.length + 3, 14)
  }));
  worksheet['!cols'] = maxProps;

  const dateStr = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(workbook, `Data_Karyawan_${brandingName.replace(/\s+/g, '_')}_${dateStr}.xlsx`);
}

/**
 * Utility to export Daily Stock Opname within a date range to Excel
 */
export function exportDailyStockOpnameToExcel(
  records: StockOpnameRecord[],
  startDate: string,
  endDate: string,
  rawItems: RawItem[],
  brandingName: string = 'Restoran'
) {
  const filtered = records.filter(r => {
    const isDaily = r.type === 'daily' || r.type === 'harian';
    if (!isDaily) return false;
    if (startDate && r.date < startDate) return false;
    if (endDate && r.date > endDate) return false;
    return true;
  });

  const rows: any[] = [];
  filtered.forEach(record => {
    record.items.forEach(item => {
      const raw = rawItems.find(i => i.id === item.itemId);
      const unit = item.unit || raw?.unit || 'unit';
      const unitCost = raw?.costPerUnit || 0;
      const differenceQty = item.physicalStock - item.systemStock;
      const totalLoss = item.differenceValue !== undefined 
        ? item.differenceValue 
        : Math.abs(differenceQty) * unitCost;

      rows.push({
        'Tgl Opname': record.date,
        'ID SO': record.id,
        'Petugas': record.conductedBy,
        'Role': record.role,
        'Area': record.area || 'All',
        'Status SO': record.status,
        'Nama Bahan Baku': item.itemName || (item as any).name || raw?.name || item.itemId,
        'Kategori': raw?.category || 'Bahan Baku',
        'Stok Sistem': item.systemStock,
        'Stok Fisik': item.physicalStock,
        'Satuan': unit,
        'Selisih Qty': Number(differenceQty.toFixed(2)),
        'HPP Satuan (Rp)': unitCost,
        'Nilai Selisih / Loss (Rp)': Math.round(totalLoss),
        'Alasan / Keterangan': item.notes || item.reason || record.notes || '-',
        'Catatan Manager': record.managerNotes || '-'
      });
    });
  });

  const worksheet = XLSX.utils.json_to_sheet(rows.length > 0 ? rows : [{ 'Info': 'Tidak ada data Stock Opname Harian pada rentang tanggal ini' }]);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'SO Harian');

  const rangeStr = `${startDate || 'Awal'}_sd_${endDate || 'Akhir'}`;
  XLSX.writeFile(workbook, `SO_Harian_${brandingName.replace(/\s+/g, '_')}_${rangeStr}.xlsx`);
}

/**
 * Utility to export Monthly Stock Opname for a chosen month to Excel
 */
export function exportMonthlyStockOpnameToExcel(
  records: StockOpnameRecord[],
  monthYear: string, // YYYY-MM
  rawItems: RawItem[],
  brandingName: string = 'Restoran'
) {
  const filtered = records.filter(r => {
    const isMonthly = r.type === 'monthly' || r.type === 'bulanan';
    if (!isMonthly) return false;
    if (monthYear && !r.date.startsWith(monthYear)) return false;
    return true;
  });

  const rows: any[] = [];
  filtered.forEach(record => {
    record.items.forEach(item => {
      const raw = rawItems.find(i => i.id === item.itemId);
      const unit = item.unit || raw?.unit || 'unit';
      const unitCost = raw?.costPerUnit || 0;
      const differenceQty = item.physicalStock - item.systemStock;
      const totalLoss = item.differenceValue !== undefined 
        ? item.differenceValue 
        : Math.abs(differenceQty) * unitCost;

      rows.push({
        'Bulan / Periode': monthYear || record.date.slice(0, 7),
        'Tgl Opname': record.date,
        'ID SO': record.id,
        'Petugas Pelaksana': record.conductedBy,
        'Role': record.role,
        'Status Approval': record.status,
        'Disetujui Oleh': record.approvedBy || '-',
        'Tgl Disetujui': record.approvedDate || '-',
        'Nama Bahan Baku': item.itemName || (item as any).name || raw?.name || item.itemId,
        'Kategori': raw?.category || 'Bahan Baku',
        'Stok Sistem': item.systemStock,
        'Stok Fisik': item.physicalStock,
        'Satuan': unit,
        'Selisih Qty': Number(differenceQty.toFixed(2)),
        'HPP Satuan (Rp)': unitCost,
        'Nilai Selisih Variance (Rp)': Math.round(totalLoss),
        'Alasan / Keterangan': item.notes || item.reason || record.notes || '-',
        'Catatan / Rekomendasi Manager': record.managerNotes || '-'
      });
    });
  });

  const worksheet = XLSX.utils.json_to_sheet(rows.length > 0 ? rows : [{ 'Info': `Tidak ada data Stock Opname Bulanan pada periode ${monthYear}` }]);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'SO Bulanan');

  XLSX.writeFile(workbook, `SO_Bulanan_${brandingName.replace(/\s+/g, '_')}_${monthYear || 'Semua'}.xlsx`);
}

/**
 * Utility to export Slow Moving raw material items to Excel
 */
export function exportSlowMovingItemsToExcel(
  items: {
    rawItem: RawItem;
    daysInactive: number;
    totalStockValue: number;
    movementStatus: string;
  }[],
  brandingName: string = 'Restoran'
) {
  const rows = items.map((item, index) => ({
    'No': index + 1,
    'Kode Item': item.rawItem.code || item.rawItem.id,
    'Nama Bahan Baku': item.rawItem.name,
    'Kategori': item.rawItem.category,
    'Stok Saat Ini': item.rawItem.currentStock,
    'Satuan Unit': item.rawItem.unit,
    'HPP Satuan (Rp)': item.rawItem.costPerUnit,
    'Total Nilai Aset Mati (Rp)': Math.round(item.totalStockValue),
    'Hari Tanpa Pergerakan': `${item.daysInactive} Hari`,
    'Tgl Terakhir Diperbarui': item.rawItem.lastUpdated || '-',
    'Status Evaluasi': item.movementStatus,
    'Rekomendasi Manajer': item.daysInactive > 60 
      ? 'Segera buat menu promo spesial atau clearance agar tidak kedaluwarsa' 
      : 'Evaluasi pembelian berikutnya (kurangi kuantiti PO)'
  }));

  const worksheet = XLSX.utils.json_to_sheet(rows.length > 0 ? rows : [{ 'Info': 'Tidak ada bahan baku slow moving terdeteksi' }]);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Slow Moving Bahan Baku');

  const dateStr = new Date().toISOString().slice(0, 10);
  XLSX.writeFile(workbook, `Laporan_Slow_Moving_${brandingName.replace(/\s+/g, '_')}_${dateStr}.xlsx`);
}
