import React, { useState } from 'react';
import { useResto } from '../../context/RestoContext';
import { RawItem, ItemCategory, ItemUnit, StorageLocation } from '../../types';
import { 
  Package, 
  Plus, 
  Search, 
  Filter, 
  AlertTriangle, 
  CheckCircle, 
  Edit3, 
  Layers, 
  ArrowUpDown,
  Sparkles,
  Trash2,
  X,
  AlertCircle
} from 'lucide-react';

export const ItemManagementView: React.FC = () => {
  const { 
    rawItems, 
    menuItems,
    addRawItem, 
    updateRawItem, 
    deleteRawItem, 
    currentUser, 
    formatRupiah, 
    setActiveTab 
  } = useResto();

  const isManager = currentUser.role === 'manager' || currentUser.isMasterAdmin;

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedLocation, setSelectedLocation] = useState<string>('all');
  const [stockStatusFilter, setStockStatusFilter] = useState<'all' | 'critical' | 'safe'>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingItem, setEditingItem] = useState<RawItem | null>(null);
  const [deletingItem, setDeletingItem] = useState<RawItem | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  // Form states
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    category: 'Bahan Baku Basah' as ItemCategory,
    unit: 'kg' as ItemUnit,
    currentStock: 0,
    minimumStock: 5,
    costPerUnit: 25000,
    location: 'Kitchen' as StorageLocation,
  });

  const categories: ItemCategory[] = [
    'Bahan Baku Basah',
    'Bahan Baku Kering',
    'Bumbu & Saus',
    'Dairy & Telur',
    'Daging & Seafood',
    'Minuman & Sirup',
    'Packaging & Supplies',
    'Perlengkapan Floor',
  ];

  const units: ItemUnit[] = ['kg', 'gram', 'liter', 'ml', 'pcs', 'pack', 'can', 'portion'];
  const locations: StorageLocation[] = ['Kitchen', 'Floor / Bar', 'Gudang Central', 'Chiller / Freezer'];

  // Filter items
  const filteredItems = rawItems.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          item.code.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesLoc = selectedLocation === 'all' || item.location === selectedLocation;
    const isCritical = item.currentStock <= item.minimumStock;
    const matchesStatus = stockStatusFilter === 'all' 
      ? true 
      : stockStatusFilter === 'critical' ? isCritical : !isCritical;

    return matchesSearch && matchesCat && matchesLoc && matchesStatus;
  });

  const criticalCount = rawItems.filter(i => i.currentStock <= i.minimumStock).length;

  const handleCreateItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    const itemCode = formData.code.trim() || `BB-${String(rawItems.length + 1).padStart(3, '0')}`;

    addRawItem({
      code: itemCode,
      name: formData.name.trim(),
      category: formData.category,
      unit: formData.unit,
      currentStock: Number(formData.currentStock),
      minimumStock: Number(formData.minimumStock),
      costPerUnit: Number(formData.costPerUnit),
      location: formData.location,
    });

    setShowAddModal(false);
    setFormData({
      code: '',
      name: '',
      category: 'Bahan Baku Basah',
      unit: 'kg',
      currentStock: 0,
      minimumStock: 5,
      costPerUnit: 25000,
      location: 'Kitchen',
    });
  };

  const handleUpdateItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;

    updateRawItem(editingItem.id, {
      name: editingItem.name,
      code: editingItem.code,
      category: editingItem.category,
      unit: editingItem.unit,
      currentStock: Number(editingItem.currentStock),
      minimumStock: Number(editingItem.minimumStock),
      costPerUnit: Number(editingItem.costPerUnit),
      location: editingItem.location,
    });

    setEditingItem(null);
    setActionMessage(`Bahan "${editingItem.name}" berhasil diperbarui.`);
    setTimeout(() => setActionMessage(null), 3500);
  };

  const handleConfirmDeleteItem = () => {
    if (!deletingItem) return;
    const success = deleteRawItem(deletingItem.id);
    if (success) {
      setActionMessage(`Bahan baku "${deletingItem.name}" (${deletingItem.code}) berhasil dihapus.`);
    } else {
      setActionMessage(`Gagal menghapus bahan "${deletingItem.name}".`);
    }
    setTimeout(() => setActionMessage(null), 3500);
    setDeletingItem(null);
  };

  // Check if an item is used in any menu
  const getItemUsedInMenus = (itemId: string) => {
    return menuItems.filter(m => m.recipes.some(r => r.itemId === itemId));
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-black text-slate-900">Master Data Bahan Baku & Inventaris</h2>
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
              {rawItems.length} Total Bahan
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Input bahan baku baru, monitor stok aktual secara real-time, dan setel batas notifikasi stok minimum.
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => setActiveTab('recipes')}
            className="flex-1 sm:flex-initial px-3 py-2 border border-slate-200 hover:bg-slate-50 rounded-xl text-xs font-bold text-slate-700 transition-colors"
          >
            Lihat Resep & HPP
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex-1 sm:flex-initial px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>Tambah Bahan Baru</span>
          </button>
        </div>
      </div>

      {/* Action Message Feedback Toast */}
      {actionMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-300 text-emerald-900 rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{actionMessage}</span>
        </div>
      )}

      {/* Critical Stock Alert Bar */}
      {criticalCount > 0 && (
        <div className="bg-gradient-to-r from-red-500 to-rose-600 text-white p-4 rounded-2xl shadow-md flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-xl">
              <AlertTriangle className="w-5 h-5 text-white" />
            </div>
            <div>
              <h4 className="font-extrabold text-sm">Peringatan Otomatis: {criticalCount} Item Mencapai Level Minimum!</h4>
              <p className="text-xs text-red-100 mt-0.5">
                Stok aktual berada pada atau di bawah batas minimum pemesanan. Segera lakukan receiving dari supplier atau belanja kas kecil.
              </p>
            </div>
          </div>
          <button
            onClick={() => setStockStatusFilter('critical')}
            className="hidden sm:block px-3.5 py-1.5 bg-white text-red-700 hover:bg-red-50 rounded-xl text-xs font-extrabold transition-all"
          >
            Filter Bahan Kritis
          </button>
        </div>
      )}

      {/* Filters & Search Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Cari nama bahan baku atau kode (misal: Sapi, Ayam, Kopi)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all"
            />
          </div>

          {/* Category Filter */}
          <div className="w-full sm:w-48">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 font-medium text-slate-700"
            >
              <option value="all">Semua Kategori</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          {/* Storage Location Filter */}
          <div className="w-full sm:w-44">
            <select
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(e.target.value)}
              className="w-full py-2 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 font-medium text-slate-700"
            >
              <option value="all">Semua Lokasi</option>
              {locations.map(loc => (
                <option key={loc} value={loc}>{loc}</option>
              ))}
            </select>
          </div>

          {/* Status Buttons */}
          <div className="flex rounded-xl bg-slate-100 p-1 shrink-0">
            <button
              onClick={() => setStockStatusFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                stockStatusFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Semua ({rawItems.length})
            </button>
            <button
              onClick={() => setStockStatusFilter('critical')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ${
                stockStatusFilter === 'critical' ? 'bg-red-600 text-white shadow-xs' : 'text-red-600 hover:bg-red-50'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              Kritis ({criticalCount})
            </button>
          </div>

        </div>
      </div>

      {/* Table of Inventory */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
                <th className="py-3.5 px-4">Kode & Nama Bahan</th>
                <th className="py-3.5 px-4">Kategori</th>
                <th className="py-3.5 px-4">Lokasi</th>
                <th className="py-3.5 px-4">Harga Beli / Unit</th>
                <th className="py-3.5 px-4">Stok Minimum</th>
                <th className="py-3.5 px-4">Stok Aktual Sistem</th>
                <th className="py-3.5 px-4 text-center">Status</th>
                <th className="py-3.5 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400">
                    Tidak ada bahan baku yang cocok dengan kriteria pencarian.
                  </td>
                </tr>
              ) : (
                filteredItems.map(item => {
                  const isCritical = item.currentStock <= item.minimumStock;
                  const ratio = Math.min(100, Math.round((item.currentStock / (item.minimumStock * 2)) * 100));

                  return (
                    <tr key={item.id} className={`hover:bg-slate-50/80 transition-colors ${isCritical ? 'bg-red-50/20' : ''}`}>
                      <td className="py-3.5 px-4 font-bold text-slate-900">
                        <div>{item.name}</div>
                        <span className="text-[10px] text-slate-400 font-normal">{item.code}</span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 font-medium">
                        {item.category}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-700">
                          {item.location}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-slate-700">
                        {formatRupiah(item.costPerUnit)} <span className="text-slate-400 font-normal">/ {item.unit}</span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 font-medium">
                        {item.minimumStock} {item.unit}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <span className={`text-sm font-black ${isCritical ? 'text-red-600' : 'text-slate-900'}`}>
                            {item.currentStock.toFixed(1)} {item.unit}
                          </span>
                        </div>
                        {/* Visual stock health bar */}
                        <div className="w-24 h-1.5 bg-slate-200 rounded-full mt-1 overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all ${isCritical ? 'bg-red-500' : 'bg-emerald-500'}`}
                            style={{ width: `${ratio}%` }}
                          />
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        {isCritical ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-red-100 text-red-700">
                            <AlertTriangle className="w-3 h-3" />
                            Kritis
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            <CheckCircle className="w-3 h-3" />
                            Aman
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setEditingItem(item)}
                            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors inline-flex items-center gap-1"
                            title="Edit Bahan / Penyesuaian Cepat"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span className="text-[11px] font-semibold">Edit</span>
                          </button>
                          {isManager && (
                            <button
                              onClick={() => setDeletingItem(item)}
                              className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors inline-flex items-center gap-1"
                              title="Hapus Bahan Baku yang Tidak Terpakai (Manager)"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span className="text-[11px] font-semibold hidden sm:inline">Hapus</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Tambah Bahan Baru */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 animate-in fade-in duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-slate-100 text-slate-900">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Input Data Bahan Baku Baru</h3>
                  <p className="text-xs text-slate-500">Daftarkan bahan baku atau kemasan baru ke sistem</p>
                </div>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-700 font-bold text-lg"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCreateItem} className="space-y-3.5 mt-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Kode Bahan (Opsional)</label>
                  <input
                    type="text"
                    placeholder="Auto: BB-016"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Kategori <span className="text-red-500">*</span></label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value as ItemCategory })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 font-medium"
                  >
                    {categories.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Nama Bahan Baku <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Bawang Bombay Kupas, Tepung Terigu Segitiga"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Satuan Dasar <span className="text-red-500">*</span></label>
                  <select
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value as ItemUnit })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 font-medium"
                  >
                    {units.map(u => (
                      <option key={u} value={u}>{u}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Lokasi Penyimpanan <span className="text-red-500">*</span></label>
                  <select
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value as StorageLocation })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 font-medium"
                  >
                    {locations.map(l => (
                      <option key={l} value={l}>{l}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Stok Awal</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    value={formData.currentStock}
                    onChange={(e) => setFormData({ ...formData, currentStock: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1 text-red-600">Batas Min Alert</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    required
                    value={formData.minimumStock}
                    onChange={(e) => setFormData({ ...formData, minimumStock: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Harga Beli (Rp)</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formData.costPerUnit}
                    onChange={(e) => setFormData({ ...formData, costPerUnit: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-slate-900 font-bold"
                  />
                </div>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl text-[11px] text-amber-800 border border-amber-200 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>
                  Sistem akan otomatis mengirimkan notifikasi peringatan jika stok aktual berada pada atau di bawah <strong>Batas Min Alert</strong>.
                </span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-slate-200 hover:bg-slate-50 rounded-xl text-xs font-bold text-slate-700"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                >
                  Simpan Bahan Baru
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Edit Item */}
      {editingItem && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 animate-in fade-in duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-black text-slate-900">Edit / Sesuaikan Bahan: {editingItem.name}</h3>
              <button
                onClick={() => setEditingItem(null)}
                className="text-slate-400 hover:text-slate-700 font-bold text-lg"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleUpdateItem} className="space-y-3 mt-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Nama Bahan</label>
                <input
                  type="text"
                  value={editingItem.name}
                  onChange={(e) => setEditingItem({ ...editingItem, name: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Harga Beli per Satuan (Rp)</label>
                  <input
                    type="number"
                    value={editingItem.costPerUnit}
                    onChange={(e) => setEditingItem({ ...editingItem, costPerUnit: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1 text-red-600">Batas Stok Minimum</label>
                  <input
                    type="number"
                    step="0.1"
                    value={editingItem.minimumStock}
                    onChange={(e) => setEditingItem({ ...editingItem, minimumStock: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Koreksi Stok Aktual Sistem ({editingItem.unit})</label>
                <input
                  type="number"
                  step="0.1"
                  value={editingItem.currentStock}
                  onChange={(e) => setEditingItem({ ...editingItem, currentStock: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-extrabold text-sm text-slate-900"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  *Untuk penyesuaian berkala, disarankan menggunakan modul Stock Opname atau Receiving.
                </span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingItem(null)}
                  className="px-4 py-2 border border-slate-200 hover:bg-slate-50 rounded-xl text-xs font-bold text-slate-700"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                >
                  Simpan Perubahan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Hapus Bahan Baku Tidak Terpakai */}
      {deletingItem && (() => {
        const usedMenus = getItemUsedInMenus(deletingItem.id);
        const isUsed = usedMenus.length > 0;

        return (
          <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 border border-slate-200 animate-in fade-in duration-200">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl bg-rose-100 text-rose-700">
                    <Trash2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-black text-slate-900">Hapus Bahan Baku</h3>
                    <p className="text-xs text-slate-500">Pembersihan item inventaris yang sudah tidak terpakai</p>
                  </div>
                </div>
                <button
                  onClick={() => setDeletingItem(null)}
                  className="text-slate-400 hover:text-slate-700 font-bold text-lg"
                >
                  &times;
                </button>
              </div>

              <div className="mt-4 space-y-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="font-extrabold text-sm text-slate-900">{deletingItem.name}</div>
                  <div className="text-slate-500 mt-0.5">
                    Kode: <strong className="text-slate-700">{deletingItem.code}</strong> • Kategori: {deletingItem.category}
                  </div>
                  <div className="text-slate-500 mt-0.5">
                    Stok saat ini: <strong className="text-slate-900">{deletingItem.currentStock} {deletingItem.unit}</strong> (@ {formatRupiah(deletingItem.costPerUnit)})
                  </div>
                </div>

                {isUsed ? (
                  <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl space-y-1.5">
                    <div className="flex items-center gap-1.5 font-bold text-amber-900">
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>Perhatian: Bahan ini digunakan di {usedMenus.length} Resep Menu!</span>
                    </div>
                    <p className="text-[11px] text-amber-800">
                      Bahan ini masih tercatat aktif di resep menu berikut:
                    </p>
                    <ul className="list-disc list-inside text-[11px] text-amber-900 font-medium pl-1">
                      {usedMenus.map(m => (
                        <li key={m.id}>{m.name} ({m.code})</li>
                      ))}
                    </ul>
                    <p className="text-[10px] text-amber-700 mt-1">
                      * Disarankan untuk menghapus atau mengganti bahan pada resep menu terkait terlebih dahulu sebelum menghapus item ini dari inventaris.
                    </p>
                  </div>
                ) : (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-emerald-800">
                    <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Item ini <strong>tidak digunakan</strong> di menu manapun. Aman untuk dihapus.</span>
                  </div>
                )}

                <p className="text-slate-600">
                  Apakah Anda yakin ingin menghapus item ini secara permanen dari sistem inventaris?
                </p>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setDeletingItem(null)}
                    className="px-4 py-2 border border-slate-200 hover:bg-slate-100 rounded-xl font-bold text-slate-700"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    onClick={handleConfirmDeleteItem}
                    className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold shadow-xs transition-all"
                  >
                    Ya, Hapus Item
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

    </div>
  );
};
